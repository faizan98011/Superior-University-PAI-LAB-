# from flask import Flask, render_template, request, jsonify
# import requests
# from datetime import datetime
# import re
# import random
# import os

# app = Flask(__name__)

# # OpenWeatherMap API configuration
# API_KEY = os.getenv('OPENWEATHER_API_KEY', 'c7f8a54be442d2ce457076f410730800')
# BASE_URL = 'http://api.openweathermap.org/data/2.5/weather'
# FORECAST_URL = 'http://api.openweathermap.org/data/2.5/forecast'

# # Chatbot responses
# RESPONSES = {
#     "greetings": ["hello", "hi", "hey", "greetings"],
#     "goodbye": ["bye", "goodbye", "see you", "quit"],
#     "thanks": ["thanks", "thank you", "appreciate it"],
#     "help": ["help", "what can you do", "functions"],
#     "weather": ["weather", "temperature", "forecast", "humidity", "wind", "pressure", "visibility"]
# }

# REPLIES = {
#     "greetings": ["Hello! I'm your weather assistant. How can I help?", 
#                  "Hi there! Ready to check some weather?"],
#     "goodbye": ["Goodbye! Stay dry!", 
#                 "See you later! Don't forget your umbrella!"],
#     "thanks": ["You're welcome!", 
#                "Happy to help!", 
#                "Anytime! Let me know if you need more weather info."],
#     "help": ["I can tell you about weather conditions anywhere. Try asking:",
#              "- What's the weather in London?",
#              "- How's the weather today in New York?",
#              "- Temperature in Tokyo",
#              "- Weather forecast for Paris",
#              "- Show me a graph for Berlin"],
#     "default": ["I'm a weather bot. Ask me about weather in any city!",
#                 "Sorry, I only do weather. Try asking about conditions in a specific city."],
#     "error": ["Hmm, I'm having trouble getting weather data right now.",
#               "My weather sensors seem to be offline. Try again later."]
# }

# def get_random_response(response_type):
#     """Get a random response from the available options for a given type"""
#     options = REPLIES.get(response_type, REPLIES["default"])
#     return random.choice(options)

# def extract_city(text):
#     """Improved city extraction from user message"""
#     patterns = [
#         r"(?:weather|temperature|forecast|graph).*?(?:in|for|at|of)\s+(.*)",
#         r"(?:what's|how is|tell me|show me).*?(?:weather|temperature|forecast|graph).*?(?:in|for|at|of)\s+(.*)",
#         r"^(?!.*(?:weather|temperature|forecast|graph))(.+)$"
#     ]
    
#     for pattern in patterns:
#         match = re.search(pattern, text, re.IGNORECASE)
#         if match:
#             city = match.group(1).strip()
#             city = re.sub(r'[?.,;!]*$', '', city)
#             return city
    
#     return None

# def get_weather_data(city):
#     """Fetch weather data from API"""
#     try:
#         # Fetch current weather
#         params = {
#             'q': city,
#             'appid': API_KEY,
#             'units': 'metric'
#         }
#         response = requests.get(BASE_URL, params=params)
#         if response.status_code == 200:
#             data = response.json()
#             weather = {
#                 'city': data['name'],
#                 'temperature': data['main']['temp'],
#                 'description': data['weather'][0]['description'],
#                 'icon': data['weather'][0]['icon'],
#                 'humidity': data['main']['humidity'],
#                 'feels_like': data['main']['feels_like'],
#                 'wind_speed': data['wind']['speed'],
#                 'visibility': data.get('visibility', 'N/A'),
#                 'pressure': data['main']['pressure'],
#                 'dew_point': data['main']['temp_min']
#             }

#             # Fetch 24-hour forecast
#             forecast_response = requests.get(FORECAST_URL, params=params)
#             if forecast_response.status_code == 200:
#                 forecast = forecast_response.json()
#                 forecast_data = []
#                 for entry in forecast['list'][:8]:  # Next 24 hours (3-hour intervals)
#                     forecast_data.append({
#                         'time': entry['dt_txt'],
#                         'temperature': entry['main']['temp'],
#                         'description': entry['weather'][0]['description'],
#                         'icon': entry['weather'][0]['icon']
#                     })
#                 return weather, forecast_data, None
#             else:
#                 return weather, None, "Forecast data not available."
#         else:
#             return None, None, "City not found. Please try again."
#     except Exception as e:
#         print(f"Error getting weather: {e}")
#         return None, None, "An error occurred. Please try again later."

# def format_weather_response(weather_data, forecast_data):
#     """Format weather data for chat response"""
#     response = [
#         f"<div class='weather-response'>",
#         f"<div class='weather-header'>",
#         f"<img src='/static/icons/{weather_data['icon']}.png' class='weather-icon'>",
#         f"<h3>{weather_data['city']}</h3>",
#         f"</div>",
#         f"<div class='weather-details'>",
#         f"<p><strong>🌡 Temperature:</strong> {weather_data['temperature']}°C (Feels like {weather_data['feels_like']}°C)</p>",
#         f"<p><strong>☁️ Condition:</strong> {weather_data['description'].capitalize()}</p>",
#         f"<p><strong>💧 Humidity:</strong> {weather_data['humidity']}%</p>",
#         f"<p><strong>🌬 Wind:</strong> {weather_data['wind_speed']} m/s</p>",
#         f"<p><strong>👀 Visibility:</strong> {weather_data['visibility']} meters</p>",
#         f"<p><strong>📊 Pressure:</strong> {weather_data['pressure']} hPa</p>",
#         f"<p><strong>🌫 Dew Point:</strong> {weather_data['dew_point']}°C</p>",
#         f"</div>",
#         f"<div class='forecast-header'><strong>24-Hour Forecast:</strong></div>",
#         f"<div class='forecast-container'>"
#     ]
    
#     for entry in forecast_data:
#         response.append(
#             f"<div class='forecast-item'>"
#             f"<p><strong>🕒 {entry['time']}</strong></p>"
#             f"<img src='/static/icons/{entry['icon']}.png' class='forecast-icon'>"
#             f"<p>{entry['temperature']}°C</p>"
#             f"<p>{entry['description']}</p>"
#             f"</div>"
#         )
    
#     response.append("</div>")
#     response.append(f"<a href='/graph?city={weather_data['city']}' class='graph-link'>View Temperature Graph</a>")
#     response.append("</div>")
    
#     return "".join(response)

# def process_message(message):
#     """Determine the appropriate response"""
#     message = message.lower().strip()
    
#     # Check for greetings
#     if any(word in message for word in RESPONSES["greetings"]):
#         return {'type': 'text', 'content': get_random_response("greetings")}
    
#     # Check for goodbye
#     if any(word in message for word in RESPONSES["goodbye"]):
#         return {'type': 'text', 'content': get_random_response("goodbye")}
    
#     # Check for thanks
#     if any(word in message for word in RESPONSES["thanks"]):
#         return {'type': 'text', 'content': get_random_response("thanks")}
    
#     # Check for help
#     if any(word in message for word in RESPONSES["help"]):
#         return {'type': 'text', 'content': "<br>".join(REPLIES["help"])}
    
#     # Check for weather queries
#     if any(word in message for word in RESPONSES["weather"]):
#         city = extract_city(message)
#         if city:
#             weather_data, forecast_data, error = get_weather_data(city)
#             if weather_data:
#                 # Update body class based on weather condition
#                 icon = weather_data['icon']
#                 weather_class = ''
#                 if icon.startswith('01'):
#                     weather_class = 'sunny'
#                 elif icon.startswith('02') or icon.startswith('03') or icon.startswith('04'):
#                     weather_class = 'cloudy'
#                 elif icon.startswith('09') or icon.startswith('10'):
#                     weather_class = 'rainy'
                
#                 return {
#                     'type': 'weather',
#                     'content': format_weather_response(weather_data, forecast_data),
#                     'weather_class': weather_class
#                 }
#             else:
#                 return {'type': 'text', 'content': error}
#         else:
#             return {'type': 'text', 'content': "Please specify a city name. Example: 'weather in London'"}
    
#     # Default response for unrecognized input
#     return {'type': 'text', 'content': get_random_response("default")}

# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/graph')
# def graph():
#     city = request.args.get('city')
#     if city:
#         _, forecast_data, _ = get_weather_data(city)
#         return render_template('graph.html', forecast_data=forecast_data, city=city)
#     return render_template('graph.html', forecast_data=None, city=None)

# @app.route('/chat', methods=['POST'])
# def chat():
#     user_message = request.form['message']
#     response = process_message(user_message)
#     return jsonify(response)

# if __name__ == '__main__':
#     app.run(debug=True)

# from flask import Flask, render_template, request, jsonify, session
# import requests
# import re
# import random
# import os
# from datetime import datetime

# app = Flask(__name__)
# app.secret_key = '6ef0e1f64baeafc941124500bde48e9f23565de894d16965'  # Needed for session handling

# # WeatherAPI configuration
# API_KEY = '4c3c58fa886240119b044516251703'
# BASE_URL = 'http://api.weatherapi.com/v1/current.json'
# FORECAST_URL = 'http://api.weatherapi.com/v1/forecast.json'

# # Enhanced conversational responses
# CONVERSATION_FLOW = {
#     "greetings": {
#         "triggers": ["hello", "hi", "hey", "greetings"],
#         "responses": [
#             "Hello! I'm your weather assistant. How can I help?",
#             "Hi there! Ready to check some weather?"
#         ]
#     },
#     "goodbye": {
#         "triggers": ["bye", "goodbye", "see you", "quit"],
#         "responses": [
#             "Goodbye! Stay dry!",
#             "See you later! Don't forget your umbrella!"
#         ]
#     },
#     "thanks": {
#         "triggers": ["thanks", "thank you", "appreciate"],
#         "responses": [
#             "You're welcome!",
#             "Happy to help!",
#             "Anytime! Let me know if you need more weather info."
#         ]
#     },
#     "help": {
#         "triggers": ["help", "what can you do", "functions"],
#         "responses": [
#             "I can tell you about weather conditions anywhere. Try asking:",
#             "- What's the weather in London?",
#             "- How's the weather today in New York?",
#             "- Temperature in Tokyo",
#             "- Weather forecast for Paris",
#             "- Show me a graph for Berlin"
#         ]
#     }
# }

# def get_random_response(response_type):
#     """Get contextual response"""
#     return random.choice(CONVERSATION_FLOW[response_type]["responses"])

# def extract_location(text):
#     """Advanced location extraction with context awareness"""
#     patterns = [
#         r"(?:weather|temperature|forecast|graph|in|for)\s+(?:in|for|at|of)?\s*([a-zA-Z\s,]+)",
#         r"(?:what's|how's|tell me|show me)\s+(?:the)?\s*(?:weather|temperature)\s+(?:in|for|at)?\s*([a-zA-Z\s,]+)"
#     ]
    
#     for pattern in patterns:
#         match = re.search(pattern, text, re.IGNORECASE)
#         if match:
#             location = match.group(1).strip()
#             return re.sub(r'[?.,;!]*$', '', location)
    
#     # Check session for previous location
#     if 'last_location' in session:
#         return session['last_location']
    
#     return None

# def get_weather_data(location):
#     """Enhanced weather data fetcher with conversation context"""
#     try:
#         params = {
#             'key': API_KEY,
#             'q': location,
#             'aqi': 'no'
#         }
        
#         # Get current weather
#         current_response = requests.get(BASE_URL, params=params)
#         if current_response.status_code != 200:
#             return None, None, "Sorry, I couldn't find that location."
            
#         current_data = current_response.json()
#         session['last_location'] = location  # Remember location
        
#         # Process current weather
#         current = current_data['current']
#         location_data = current_data['location']
        
#         weather = {
#             'city': location_data['name'],
#             'region': location_data['region'],
#             'country': location_data['country'],
#             'temp_c': current['temp_c'],
#             'temp_f': current['temp_f'],
#             'condition': current['condition']['text'],
#             'icon': current['condition']['icon'],
#             'humidity': current['humidity'],
#             'feelslike_c': current['feelslike_c'],
#             'wind_kph': current['wind_kph'],
#             'vis_km': current['vis_km'],
#             'pressure_mb': current['pressure_mb'],
#             'last_updated': current['last_updated']
#         }

#         # Get forecast
#         forecast_response = requests.get(FORECAST_URL, params={**params, 'days': 3})
#         if forecast_response.status_code != 200:
#             return weather, None, None
            
#         forecast_data = forecast_response.json()
#         forecast = []
        
#         for day in forecast_data['forecast']['forecastday']:
#             daily_data = {
#                 'date': day['date'],
#                 'max_temp': day['day']['maxtemp_c'],
#                 'min_temp': day['day']['mintemp_c'],
#                 'condition': day['day']['condition']['text'],
#                 'hours': []
#             }
            
#             for hour in day['hour'][::3]:  # Every 3 hours
#                 daily_data['hours'].append({
#                     'time': hour['time'].split()[1],
#                     'temp_c': hour['temp_c'],
#                     'condition': hour['condition']['text'],
#                     'icon': hour['condition']['icon']
#                 })
            
#             forecast.append(daily_data)
        
#         return weather, forecast, None
        
#     except Exception as e:
#         print(f"Weather API Error: {str(e)}")
#         return None, None, "I'm having trouble getting weather data. Please try again."

# def format_weather_response(weather, forecast):
#     """Conversational weather report formatting"""
#     response = {
#         'type': 'weather',
#         'content': {
#             'current': weather,
#             'forecast': forecast
#         },
#         'text_response': f"""Currently in {weather['city']}, {weather['region']}:
#         {weather['condition']} at {weather['temp_c']}°C (Feels like {weather['feelslike_c']}°C)
#         Humidity: {weather['humidity']}% | Wind: {weather['wind_kph']} km/h
#         """
#     }
    
#     return response

# @app.route('/')
# def home():
#     """Render the chat interface"""
#     return render_template('index.html')

# @app.route('/chat', methods=['POST'])
# def handle_chat():
#     """Main chatbot message handler"""
#     user_message = request.form.get('message', '').lower().strip()
    
#     # Check conversation flows first
#     for intent, data in CONVERSATION_FLOW.items():
#         if any(trigger in user_message for trigger in data["triggers"]):
#             return jsonify({
#                 'type': 'text',
#                 'content': get_random_response(intent)
#             })
    
#     # Handle weather queries
#     location = extract_location(user_message)
#     if location:
#         weather, forecast, error = get_weather_data(location)
        
#         if weather:
#             return jsonify(format_weather_response(weather, forecast))
#         else:
#             return jsonify({
#                 'type': 'text',
#                 'content': error or "Sorry, I couldn't get weather for that location."
#             })
    
#     # Default response
#     return jsonify({
#         'type': 'text',
#         'content': "I'm a weather bot. Ask me about weather in any city!"
#     })

# if __name__ == '__main__':
#     app.run(debug=True)

# from flask import Flask, render_template, request, jsonify, session
# import requests
# import re
# import random
# import os
# from datetime import datetime

# app = Flask(__name__)
# app.secret_key = '6ef0e1f64baeafc941124500bde48e9f23565de894d16965'

# # WeatherAPI configuration
# API_KEY = '4c3c58fa886240119b044516251703'
# BASE_URL = 'http://api.weatherapi.com/v1/current.json'
# FORECAST_URL = 'http://api.weatherapi.com/v1/forecast.json'

# # Enhanced conversational responses
# CONVERSATION_FLOW = {
#     "greetings": {
#         "triggers": ["hello", "hi", "hey", "greetings"],
#         "responses": [
#             "Hello! I'm your weather assistant. How can I help?",
#             "Hi there! Ready to check some weather?"
#         ]
#     },
#     "goodbye": {
#         "triggers": ["bye", "goodbye", "see you", "quit"],
#         "responses": [
#             "Goodbye! Stay dry!",
#             "See you later! Don't forget your umbrella!"
#         ]
#     },
#     "thanks": {
#         "triggers": ["thanks", "thank you", "appreciate"],
#         "responses": [
#             "You're welcome!",
#             "Happy to help!",
#             "Anytime! Let me know if you need more weather info."
#         ]
#     },
#     "help": {
#         "triggers": ["help", "what can you do", "functions"],
#         "responses": [
#             "I can tell you about weather conditions anywhere. Try asking:",
#             "- What's the weather in London?",
#             "- How's the weather today in New York?",
#             "- Temperature in Tokyo",
#             "- Weather forecast for Paris",
#             "- Show me a graph for Berlin"
#         ]
#     }
# }

# def get_random_response(response_type):
#     return random.choice(CONVERSATION_FLOW[response_type]["responses"])

# def extract_location(text):
#     patterns = [
#         r"(?:weather|temperature|forecast|graph|in|for)\s+(?:in|for|at|of)?\s*([a-zA-Z\s,]+)",
#         r"(?:what's|how's|tell me|show me)\s+(?:the)?\s*(?:weather|temperature)\s+(?:in|for|at)?\s*([a-zA-Z\s,]+)"
#     ]
    
#     for pattern in patterns:
#         match = re.search(pattern, text, re.IGNORECASE)
#         if match:
#             location = match.group(1).strip()
#             return re.sub(r'[?.,;!]*$', '', location)
    
#     if 'last_location' in session:
#         return session['last_location']
    
#     return None

# def get_weather_data(location):
#     try:
#         params = {
#             'key': API_KEY,
#             'q': location,
#             'aqi': 'no'
#         }
        
#         current_response = requests.get(BASE_URL, params=params)
#         if current_response.status_code != 200:
#             return None, None, "Sorry, I couldn't find that location."
            
#         current_data = current_response.json()
#         session['last_location'] = location
        
#         current = current_data['current']
#         location_data = current_data['location']
        
#         weather = {
#             'city': location_data['name'],
#             'region': location_data['region'],
#             'country': location_data['country'],
#             'temp_c': current['temp_c'],
#             'condition': current['condition']['text'],
#             'icon': current['condition']['icon'],
#             'humidity': current['humidity'],
#             'feelslike_c': current['feelslike_c'],
#             'wind_kph': current['wind_kph'],
#             'vis_km': current['vis_km']
#         }

#         forecast_response = requests.get(FORECAST_URL, params={**params, 'days': 1})
#         if forecast_response.status_code != 200:
#             return weather, None, None
            
#         forecast_data = forecast_response.json()
#         forecast = []
        
#         for hour in forecast_data['forecast']['forecastday'][0]['hour'][::3][:8]:
#             forecast.append({
#                 'time': hour['time'].split()[1],
#                 'temp_c': hour['temp_c'],
#                 'condition': hour['condition']['text'],
#                 'icon': hour['condition']['icon']
#             })
        
#         return weather, forecast, None
        
#     except Exception as e:
#         print(f"Weather API Error: {str(e)}")
#         return None, None, "I'm having trouble getting weather data. Please try again."

# def format_weather_response(weather, forecast):
#     response = {
#         'type': 'weather',
#         'content': f"""
#         <div class='weather-response'>
#             <div class='weather-header'>
#                 <img src='{weather['icon']}' class='weather-icon'>
#                 <h3>{weather['city']}, {weather['region']}</h3>
#             </div>
#             <div class='weather-details'>
#                 <p><strong>🌡 Temperature:</strong> {weather['temp_c']}°C (Feels like {weather['feelslike_c']}°C)</p>
#                 <p><strong>☁️ Condition:</strong> {weather['condition']}</p>
#                 <p><strong>💧 Humidity:</strong> {weather['humidity']}%</p>
#                 <p><strong>🌬 Wind:</strong> {weather['wind_kph']} km/h</p>
#             </div>
#             <div class='forecast-header'><strong>24-Hour Forecast:</strong></div>
#             <div class='forecast-container'>
#                 {''.join([
#                     f"""
#                     <div class='forecast-item'>
#                         <p><strong>🕒 {hour['time']}</strong></p>
#                         <img src='{hour['icon']}' class='forecast-icon'>
#                         <p>{hour['temp_c']}°C</p>
#                         <p>{hour['condition']}</p>
#                     </div>
#                     """ for hour in forecast
#                 ])}
#             </div>
#             <a href='/graph?city={weather['city']}' class='graph-link'>View Temperature Graph</a>
#         </div>
#         """
#     }
#     return response

# @app.route('/')
# def home():
#     return render_template('index.html')  # Make sure this matches your template filename

# @app.route('/chat', methods=['POST'])
# def handle_chat():
#     user_message = request.form.get('message', '').lower().strip()
    
#     for intent, data in CONVERSATION_FLOW.items():
#         if any(trigger in user_message for trigger in data["triggers"]):
#             return jsonify({
#                 'type': 'text',
#                 'content': get_random_response(intent)
#             })
    
#     location = extract_location(user_message)
#     if location:
#         weather, forecast, error = get_weather_data(location)
#         if weather:
#             return jsonify(format_weather_response(weather, forecast))
#         else:
#             return jsonify({
#                 'type': 'text',
#                 'content': error or "Sorry, I couldn't get weather for that location."
#             })
    
#     return jsonify({
#         'type': 'text',
#         'content': "I'm a weather bot. Ask me about weather in any city!"
#     })

# @app.route('/graph')
# def graph():
#     city = request.args.get('city')
#     if city:
#         _, forecast_data, _ = get_weather_data(city)
#         return render_template('graph.html', forecast_data=forecast_data, city=city)
#     return render_template('graph.html', forecast_data=None, city=None)

# if __name__ == '__main__':
#     app.run(debug=True)


# from flask import Flask, render_template, request, jsonify, session
# import requests
# import re
# import random
# import os
# from datetime import datetime

# app = Flask(__name__)
# app.secret_key = '6ef0e1f64baeafc941124500bde48e9f23565de894d16965'

# # WeatherAPI configuration
# API_KEY = '4c3c58fa886240119b044516251703'
# BASE_URL = 'http://api.weatherapi.com/v1/current.json'
# FORECAST_URL = 'http://api.weatherapi.com/v1/forecast.json'

# # Chatbot responses
# CONVERSATION_FLOW = {
#     "greetings": {
#         "triggers": ["hello", "hi", "hey", "greetings"],
#         "responses": [
#             "Hello! I'm your weather assistant. How can I help?",
#             "Hi there! Ready to check some weather?"
#         ]
#     },
#     "goodbye": {
#         "triggers": ["bye", "goodbye", "see you", "quit"],
#         "responses": [
#             "Goodbye! Stay dry!",
#             "See you later! Don't forget your umbrella!"
#         ]
#     },
#     "thanks": {
#         "triggers": ["thanks", "thank you", "appreciate"],
#         "responses": [
#             "You're welcome!",
#             "Happy to help!",
#             "Anytime! Let me know if you need more weather info."
#         ]
#     },
#     "help": {
#         "triggers": ["help", "what can you do", "functions"],
#         "responses": [
#             "I can tell you about weather conditions anywhere. Try asking:",
#             "- What's the weather in London?",
#             "- How's the weather today in New York?",
#             "- Temperature in Tokyo",
#             "- Weather forecast for Paris",
#             "- Show me a graph for Berlin"
#         ]
#     }
# }

# def get_random_response(response_type):
#     return random.choice(CONVERSATION_FLOW[response_type]["responses"])

# def extract_location(text):
#     patterns = [
#         r"(?:weather|temperature|forecast|graph|in|for)\s+(?:in|for|at|of)?\s*([a-zA-Z\s,]+)",
#         r"(?:what's|how's|tell me|show me)\s+(?:the)?\s*(?:weather|temperature)\s+(?:in|for|at)?\s*([a-zA-Z\s,]+)"
#     ]
    
#     for pattern in patterns:
#         match = re.search(pattern, text, re.IGNORECASE)
#         if match:
#             location = match.group(1).strip()
#             return re.sub(r'[?.,;!]*$', '', location)
    
#     if 'last_location' in session:
#         return session['last_location']
    
#     return None

# def get_weather_data(location):
#     try:
#         params = {
#             'key': API_KEY,
#             'q': location,
#             'aqi': 'no'
#         }
        
#         # Get current weather
#         current_response = requests.get(BASE_URL, params=params)
#         if current_response.status_code != 200:
#             return None, None, "Sorry, I couldn't find that location."
            
#         current_data = current_response.json()
#         session['last_location'] = location
        
#         current = current_data['current']
#         location_data = current_data['location']
        
#         weather = {
#             'city': location_data['name'],
#             'region': location_data['region'],
#             'country': location_data['country'],
#             'temp_c': current['temp_c'],
#             'condition': current['condition']['text'],
#             'icon': current['condition']['icon'],
#             'humidity': current['humidity'],
#             'feelslike_c': current['feelslike_c'],
#             'wind_kph': current['wind_kph'],
#             'vis_km': current['vis_km']
#         }

#         # Get forecast
#         forecast_response = requests.get(FORECAST_URL, params={**params, 'days': 1})
#         if forecast_response.status_code != 200:
#             return weather, None, None
            
#         forecast_data = forecast_response.json()
#         forecast = []
        
#         for hour in forecast_data['forecast']['forecastday'][0]['hour'][::3][:8]:
#             forecast.append({
#                 'time': hour['time'].split()[1],
#                 'temp_c': hour['temp_c'],
#                 'condition': hour['condition']['text'],
#                 'icon': hour['condition']['icon']
#             })
        
#         return weather, forecast, None
        
#     except Exception as e:
#         print(f"Weather API Error: {str(e)}")
#         return None, None, "I'm having trouble getting weather data. Please try again."

# @app.route('/')
# def home():
#     return render_template('index.html')

# @app.route('/chat', methods=['POST'])
# def handle_chat():
#     user_message = request.form.get('message', '').lower().strip()
    
#     for intent, data in CONVERSATION_FLOW.items():
#         if any(trigger in user_message for trigger in data["triggers"]):
#             return jsonify({
#                 'type': 'text',
#                 'content': get_random_response(intent)
#             })
    
#     location = extract_location(user_message)
#     if location:
#         weather, forecast, error = get_weather_data(location)
        
#         if weather:
#             response = {
#                 'type': 'weather',
#                 'content': f"""
#                 <div class='weather-response'>
#                     <div class='weather-header'>
#                         <img src='{weather['icon']}' class='weather-icon'>
#                         <h3>{weather['city']}, {weather['region']}</h3>
#                     </div>
#                     <div class='weather-details'>
#                         <p><strong>🌡 Temperature:</strong> {weather['temp_c']}°C (Feels like {weather['feelslike_c']}°C)</p>
#                         <p><strong>☁️ Condition:</strong> {weather['condition']}</p>
#                         <p><strong>💧 Humidity:</strong> {weather['humidity']}%</p>
#                         <p><strong>🌬 Wind:</strong> {weather['wind_kph']} km/h</p>
#                     </div>
#                     <div class='forecast-header'><strong>24-Hour Forecast:</strong></div>
#                     <div class='forecast-container'>
#                         {''.join([
#                             f"""
#                             <div class='forecast-item'>
#                                 <p><strong>🕒 {hour['time']}</strong></p>
#                                 <img src='{hour['icon']}' class='forecast-icon'>
#                                 <p>{hour['temp_c']}°C</p>
#                                 <p>{hour['condition']}</p>
#                             </div>
#                             """ for hour in forecast
#                         ])}
#                     </div>
#                     <a href='/graph?city={weather['city']}' class='graph-link'>View Temperature Graph</a>
#                 </div>
#                 """,
#                 'weather_class': 'sunny' if 'sun' in weather['icon'] else 'cloudy' if 'cloud' in weather['icon'] else 'rainy' if 'rain' in weather['icon'] else 'default'
#             }
#             return jsonify(response)
#         else:
#             return jsonify({
#                 'type': 'text',
#                 'content': error or "Sorry, I couldn't get weather for that location."
#             })
    
#     return jsonify({
#         'type': 'text',
#         'content': "I'm a weather bot. Ask me about weather in any city!"
#     })

# @app.route('/graph')
# def graph():
#     city = request.args.get('city')
#     if city:
#         _, forecast_data, _ = get_weather_data(city)
#         return render_template('graph.html', forecast_data=forecast_data, city=city)
#     return render_template('graph.html', forecast_data=None, city=None)

# if __name__ == '__main__':
#     app.run(debug=True)


from flask import Flask, render_template, request, jsonify, session
import requests
import re
import random
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = '6ef0e1f64baeafc941124500bde48e9f23565de894d16965'

# WeatherAPI configuration
API_KEY = '4c3c58fa886240119b044516251703'
BASE_URL = 'http://api.weatherapi.com/v1/current.json'
FORECAST_URL = 'http://api.weatherapi.com/v1/forecast.json'

# Chatbot responses
CONVERSATION_FLOW = {
    "greetings": {
        "triggers": ["hello", "hi", "hey", "greetings"],
        "responses": [
            "Hello! I'm your weather assistant. How can I help?",
            "Hi there! Ready to check some weather?"
        ]
    },
    "goodbye": {
        "triggers": ["bye", "goodbye", "see you", "quit"],
        "responses": [
            "Goodbye! Stay dry!",
            "See you later! Don't forget your umbrella!"
        ]
    },
    "thanks": {
        "triggers": ["thanks", "thank you", "appreciate"],
        "responses": [
            "You're welcome!",
            "Happy to help!",
            "Anytime! Let me know if you need more weather info."
        ]
    },
    "help": {
        "triggers": ["help", "what can you do", "functions"],
        "responses": [
            "I can tell you about weather conditions anywhere. Try asking:",
            "- What's the weather in London?",
            "- How's the weather today in New York?",
            "- Temperature in Tokyo",
            "- Weather forecast for Paris"
        ]
    }
}

def get_random_response(response_type):
    return random.choice(CONVERSATION_FLOW[response_type]["responses"])

def extract_location(text):
    patterns = [
        r"(?:weather|temperature|forecast|in|for)\s+(?:in|for|at|of)?\s*([a-zA-Z\s,]+)",
        r"(?:what's|how's|tell me|show me)\s+(?:the)?\s*(?:weather|temperature)\s+(?:in|for|at)?\s*([a-zA-Z\s,]+)"
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            location = match.group(1).strip()
            return re.sub(r'[?.,;!]*$', '', location)
    
    if 'last_location' in session:
        return session['last_location']
    
    return None

# def determine_weather_class(condition_text, icon_url):
#     condition = condition_text.lower()
#     icon = icon_url.lower()
    
#     if 'sun' in icon or 'clear' in condition:
#         return 'sunny'
#     elif 'rain' in icon or 'rain' in condition or 'drizzle' in condition:
#         return 'rainy'
#     elif 'cloud' in icon or 'overcast' in condition or 'fog' in condition:
#         return 'cloudy'
#     elif 'snow' in icon or 'snow' in condition:
#         return 'snowy'
#     elif 'thunder' in icon or 'storm' in condition:
#         return 'stormy'
#     else:
#         return 'default'
def determine_weather_class(condition_text, icon_url):
    condition = condition_text.lower()
    icon = icon_url.lower()
    
    if 'sun' in icon or 'clear' in condition:
        return 'sunny'
    elif 'rain' in icon or 'rain' in condition or 'drizzle' in condition:
        return 'rainy'
    elif 'cloud' in icon or 'overcast' in condition or 'fog' in condition:
        return 'cloudy'
    elif 'snow' in icon or 'snow' in condition:
        return 'snowy'
    elif 'thunder' in icon or 'storm' in condition:
        return 'stormy'
    else:
        return 'default'

def get_weather_data(location):
    try:
        params = {
            'key': API_KEY,
            'q': location,
            'aqi': 'yes'
        }
        
        # Get current weather
        current_response = requests.get(BASE_URL, params=params)
        if current_response.status_code != 200:
            return None, None, f"Sorry, I couldn't find weather for {location}."
            
        current_data = current_response.json()
        session['last_location'] = location
        
        current = current_data['current']
        location_data = current_data['location']
        
        weather = {
            'city': location_data['name'],
            'region': location_data['region'],
            'country': location_data['country'],
            'temp_c': current['temp_c'],
            'condition': current['condition']['text'],
            'icon': current['condition']['icon'],
            'humidity': current['humidity'],
            'feelslike_c': current['feelslike_c'],
            'wind_kph': current['wind_kph'],
            'vis_km': current['vis_km'],
            'aqi': current.get('air_quality', {}).get('us-epa-index', 'N/A')
        }

        # Get forecast
        forecast_response = requests.get(FORECAST_URL, params={**params, 'days': 1})
        if forecast_response.status_code != 200:
            return weather, None, None
            
        forecast_data = forecast_response.json()
        forecast = []
        
        for hour in forecast_data['forecast']['forecastday'][0]['hour'][::3][:8]:
            forecast.append({
                'time': hour['time'].split()[1],
                'temp_c': hour['temp_c'],
                'condition': hour['condition']['text'],
                'icon': hour['condition']['icon']
            })
        
        return weather, forecast, None
        
    except Exception as e:
        print(f"Weather API Error: {str(e)}")
        return None, None, f"I'm having trouble getting weather data for {location}. Please try again."

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def handle_chat():
    user_message = request.form.get('message', '').lower().strip()
    
    # Check for conversation triggers
    for intent, data in CONVERSATION_FLOW.items():
        if any(trigger in user_message for trigger in data["triggers"]):
            return jsonify({
                'type': 'text',
                'content': get_random_response(intent)
            })
    
    # Extract location and get weather data
    location = extract_location(user_message)
    if location:
        weather, forecast, error = get_weather_data(location)
        
        if weather:
            # Prepare AQI message
            aqi_message = ""
            if weather['aqi'] != 'N/A':
                aqi_levels = {
                    1: "Good",
                    2: "Moderate",
                    3: "Unhealthy for sensitive groups",
                    4: "Unhealthy",
                    5: "Very Unhealthy",
                    6: "Hazardous"
                }
                aqi_message = f"""
                <div class='aqi-info' style='border-left-color: {
                    'green' if weather['aqi'] <= 2 else 
                    'yellow' if weather['aqi'] <= 3 else 
                    'orange' if weather['aqi'] <= 4 else 
                    'red' if weather['aqi'] <= 5 else 'maroon'
                }'>
                    <p><strong>🌫 Air Quality Index:</strong> {aqi_levels.get(weather['aqi'], 'N/A')} ({weather['aqi']})</p>
                </div>
                """
            
            # Determine weather class for background
            weather_class = determine_weather_class(weather['condition'], weather['icon'])
            
            response = {
                'type': 'weather',
                'content': f"""
                <div class='weather-response'>
                    <div class='weather-header'>
                        <img src='{weather['icon']}' class='weather-icon'>
                        <h3>{weather['city']}, {weather['region']}, {weather['country']}</h3>
                    </div>
                    <div class='weather-details'>
                        <p><strong>🌡 Temperature:</strong> {weather['temp_c']}°C (Feels like {weather['feelslike_c']}°C)</p>
                        <p><strong>☁️ Condition:</strong> {weather['condition']}</p>
                        <p><strong>💧 Humidity:</strong> {weather['humidity']}%</p>
                        <p><strong>🌬 Wind:</strong> {weather['wind_kph']} km/h</p>
                        <p><strong>👁 Visibility:</strong> {weather['vis_km']} km</p>
                        {aqi_message}
                    </div>
                    <div class='forecast-header'><strong>24-Hour Forecast:</strong></div>
                    <div class='forecast-container'>
                        {''.join([
                            f"""
                            <div class='forecast-item'>
                                <p><strong>🕒 {hour['time']}</strong></p>
                                <img src='{hour['icon']}' class='forecast-icon'>
                                <p>{hour['temp_c']}°C</p>
                                <p>{hour['condition']}</p>
                            </div>
                            """ for hour in forecast
                        ])}
                    </div>
                </div>
                """,
                'weather_class': weather_class
            }
            return jsonify(response)
        else:
            return jsonify({
                'type': 'text',
                'content': error or f"Sorry, I couldn't get weather for {location}."
            })
    
    return jsonify({
        'type': 'text',
        'content': "I'm a weather bot. Ask me about weather in any city! (Example: 'What's the weather in London?')"
    })

if __name__ == '__main__':
    app.run(debug=True)