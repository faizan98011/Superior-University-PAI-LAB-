import cv2
import numpy as np
import imutils
from collections import Counter

# Load the pre-trained MobileNetSSD model
PROTO_PATH = "MobileNetSSD_deploy.prototxt.txt"
MODEL_PATH = "MobileNetSSD_deploy.caffemodel"

# Load model
net = cv2.dnn.readNetFromCaffe(PROTO_PATH, MODEL_PATH)

# Classes to detect
CLASSES = ["background", "aeroplane", "bicycle", "bird", "boat", "bottle", "bus", "car", "cat", "chair", "cow",
           "dining-table", "dog", "horse", "motorbike", "person", "potted plant", "sheep", "sofa", "train", "monitor"]
REQ_CLASSES = {"cow", "sheep", "horse", "dog"}  # Animals to detect

# Start video capture
cap = cv2.VideoCapture(0)  # 0 for webcam, replace with video file path if needed

CONF_THRESHOLD = 0.2  # Confidence threshold for detection
HERD_THRESHOLD = 5  # Alert if more than this number of animals detected

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = imutils.resize(frame, width=600)
    (h, w) = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(cv2.resize(frame, (300, 300)), 0.007843, (300, 300), 127.5)
    net.setInput(blob)
    detections = net.forward()

    animal_count = 0  # Count detected animals

    for i in np.arange(0, detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > CONF_THRESHOLD:
            idx = int(detections[0, 0, i, 1])
            if CLASSES[idx] in REQ_CLASSES:
                animal_count += 1
                box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
                (startX, startY, endX, endY) = box.astype("int")
                label = f"{CLASSES[idx]}: {confidence * 100:.2f}%"
                cv2.rectangle(frame, (startX, startY), (endX, endY), (0, 255, 0), 2)
                cv2.putText(frame, label, (startX, startY - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

    # Display animal count on screen
    cv2.putText(frame, f"Animals Detected: {animal_count}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255) if animal_count > HERD_THRESHOLD else (0, 255, 0), 2)

    # Alert if herd detected
    if animal_count > HERD_THRESHOLD:
        print("ALERT! Large number of animals detected!")

    cv2.imshow("Herd Detection", frame)
    
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
